# GG's Attention Marketplace

GG's is a transparent attention marketplace where Web3 projects launch campaigns, creators submit real engagement, and reward allocation is calculated from scored XP.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/ggs-marketplace/src/` — the React/Vite frontend and shared marketplace shell.
- `artifacts/api-server/src/routes/marketplace.ts` — marketplace API behavior, scoring, leaderboard aggregation, and demo seed initialization.
- `artifacts/api-server/src/reward-pool.ts` — Celo/G$ configuration and deterministic Merkle root/proof generation.
- `artifacts/ggs-marketplace/src/lib/reward-pool.ts` — injected-wallet client for funding, swapping, root publication, and creator claims.
- `lib/api-spec/openapi.yaml` — source of truth for the marketplace API contract.
- `lib/db/src/schema/campaigns.ts` — source of truth for campaign and submission tables.
- `contracts/GGsRewardPoolGDollar.sol` — supplied reward-pool contract, retained as deployment-ready but unaudited source.
- `artifacts/ggs-marketplace/src/index.css` — visual tokens and responsive styling.

## Architecture decisions

- The frontend uses generated OpenAPI hooks for every server interaction; it does not call the API with raw fetch.
- Engagement is simulated deterministically from the submission identity and link until social platform APIs are connected.
- Campaign rewards are estimated from each creator's share of campaign XP rather than being stored as a second mutable allocation record.
- The API seeds a small demo dataset only when the database is empty so a first preview is useful without hiding persistence.
- G$ payouts are tracked as an explicit lifecycle (`draft → funded → swapped → root-published → claiming`) with raw token units preserved; the backend uses the actual swap output for Merkle allocation.
- Wallet transactions are browser-injected and configuration-gated. The app does not invent deployment addresses or silently fall back to simulated blockchain writes.

## Product

- Overview with live campaign, creator, XP, and reward-pool metrics.
- Project workspace for launching campaigns and reviewing active records.
- Creator submission flow with platform, account-age trust input, deterministic engagement scoring, and XP result feedback.
- Campaign leaderboard with creator rank, pool share, and estimated reward.
- G$ reward-pool staging panel with Celo funding/swap/root actions and creator claim proof lookup.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- If the OpenAPI contract changes, run `pnpm --filter @workspace/api-spec run codegen` before typechecking or using new hooks.
- Demo seed initialization is single-flight because summary and list requests can arrive at the same time on an empty database.
- Set both `REWARD_POOL_CONTRACT_ADDRESS` and `VITE_REWARD_POOL_CONTRACT_ADDRESS` only after the reviewed contract is deployed; the current preview intentionally reports the reward pool as not configured.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
