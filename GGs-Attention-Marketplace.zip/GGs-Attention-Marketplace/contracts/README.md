# G$ reward pool deployment

`GGsRewardPoolGDollar.sol` implements the campaign payout lifecycle:

1. The project calls `createCampaign()` with a small ETH amount.
2. The project calls `finalizeSwap()` after the campaign closes, using a fresh `minGdOut` quote.
3. GG's backend builds a Merkle tree from final XP shares of the actual G$ output.
4. The project calls `publishRoot()`.
5. Creators claim G$ with their wallet and Merkle proof.

## Before deployment

- Target Celo first; the supplied notes identify it as the deepest G$ liquidity venue.
- Verify WETH, Uniswap V3 SwapRouter, the WETH/G$ fee tier, and GoodDollar Identity addresses from current official documentation/onchain state.
- Review and audit the contract. It is hackathon/testnet-grade and should not receive real funds without professional review.
- Use small demo amounts. Thin G$ liquidity makes large single swaps unsafe.

## App configuration

After deployment, configure the same deployed address in both services:

- `REWARD_POOL_CONTRACT_ADDRESS` — API server distribution/config response.
- `VITE_REWARD_POOL_CONTRACT_ADDRESS` — browser wallet transaction client.

The app intentionally remains in a staged, non-signing state while either address is unset.