// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/cryptography/MerkleProof.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface IWETH9 is IERC20 {
    function deposit() external payable;
}

interface ISwapRouter {
    struct ExactInputSingleParams {
        address tokenIn;
        address tokenOut;
        uint24 fee;
        address recipient;
        uint256 deadline;
        uint256 amountIn;
        uint256 amountOutMinimum;
        uint160 sqrtPriceLimitX96;
    }

    function exactInputSingle(
        ExactInputSingleParams calldata params
    ) external payable returns (uint256 amountOut);
}

interface IGoodDollarIdentity {
    function isWhitelisted(address account) external view returns (bool);
}

/// @title GGsRewardPoolGDollar
/// @notice Projects fund campaigns with ETH, swap the pool to G$, then publish
/// an XP-based Merkle distribution for creators to claim.
///
/// This contract is deployment-ready, but the router, WETH, identity registry,
/// fee tier, and contract address must be configured and verified per chain.
/// Review and audit before sending real funds.
contract GGsRewardPoolGDollar is Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    IWETH9 public immutable WETH;
    IERC20 public immutable GDOLLAR;
    ISwapRouter public immutable swapRouter;
    IGoodDollarIdentity public identityRegistry;
    uint24 public gdPoolFee;

    struct Campaign {
        address project;
        uint256 ethDeposited;
        uint256 gdPool;
        uint256 gdClaimed;
        bytes32 merkleRoot;
        bool requireIdentity;
        bool swapped;
        bool finalized;
        uint64 claimDeadline;
    }

    uint256 public campaignCount;
    mapping(uint256 => Campaign) public campaigns;
    mapping(uint256 => mapping(address => bool)) public hasClaimed;

    event CampaignCreated(
        uint256 indexed campaignId,
        address indexed project,
        uint256 ethDeposited,
        bool requireIdentity
    );
    event Swapped(uint256 indexed campaignId, uint256 ethIn, uint256 gdOut);
    event RootPublished(uint256 indexed campaignId, bytes32 merkleRoot);
    event Claimed(uint256 indexed campaignId, address indexed creator, uint256 amount);
    event UnclaimedWithdrawn(uint256 indexed campaignId, uint256 amount);

    constructor(
        address _weth,
        address _gDollar,
        address _swapRouter,
        address _identityRegistry,
        uint24 _gdPoolFee
    ) Ownable(msg.sender) {
        WETH = IWETH9(_weth);
        GDOLLAR = IERC20(_gDollar);
        swapRouter = ISwapRouter(_swapRouter);
        identityRegistry = IGoodDollarIdentity(_identityRegistry);
        gdPoolFee = _gdPoolFee;
    }

    function createCampaign(
        bool requireIdentity,
        uint64 claimWindowSeconds
    ) external payable returns (uint256 campaignId) {
        require(msg.value > 0, "must deposit ETH");
        if (requireIdentity) {
            require(
                address(identityRegistry) != address(0),
                "identity registry not set on this chain"
            );
        }

        campaignId = campaignCount++;
        campaigns[campaignId] = Campaign({
            project: msg.sender,
            ethDeposited: msg.value,
            gdPool: 0,
            gdClaimed: 0,
            merkleRoot: bytes32(0),
            requireIdentity: requireIdentity,
            swapped: false,
            finalized: false,
            claimDeadline: uint64(block.timestamp) + claimWindowSeconds
        });
        emit CampaignCreated(campaignId, msg.sender, msg.value, requireIdentity);
    }

    function finalizeSwap(uint256 campaignId, uint256 minGdOut)
        external
        nonReentrant
    {
        Campaign storage c = campaigns[campaignId];
        require(msg.sender == c.project, "only campaign owner");
        require(!c.swapped, "already swapped");

        WETH.deposit{value: c.ethDeposited}();
        WETH.approve(address(swapRouter), c.ethDeposited);

        ISwapRouter.ExactInputSingleParams memory params =
            ISwapRouter.ExactInputSingleParams({
                tokenIn: address(WETH),
                tokenOut: address(GDOLLAR),
                fee: gdPoolFee,
                recipient: address(this),
                deadline: block.timestamp,
                amountIn: c.ethDeposited,
                amountOutMinimum: minGdOut,
                sqrtPriceLimitX96: 0
            });

        uint256 gdOut = swapRouter.exactInputSingle(params);
        c.gdPool = gdOut;
        c.swapped = true;
        emit Swapped(campaignId, c.ethDeposited, gdOut);
    }

    function publishRoot(uint256 campaignId, bytes32 merkleRoot) external {
        Campaign storage c = campaigns[campaignId];
        require(msg.sender == c.project, "only campaign owner");
        require(c.swapped, "swap to G$ first");
        require(!c.finalized, "root already published");
        c.merkleRoot = merkleRoot;
        c.finalized = true;
        emit RootPublished(campaignId, merkleRoot);
    }

    function claim(
        uint256 campaignId,
        uint256 amount,
        bytes32[] calldata proof
    ) external nonReentrant {
        Campaign storage c = campaigns[campaignId];
        require(c.finalized, "distribution not published yet");
        require(!hasClaimed[campaignId][msg.sender], "already claimed");
        require(block.timestamp <= c.claimDeadline, "claim window closed");

        if (c.requireIdentity) {
            require(
                identityRegistry.isWhitelisted(msg.sender),
                "wallet not verified as unique human"
            );
        }

        bytes32 leaf = keccak256(abi.encodePacked(campaignId, msg.sender, amount));
        require(MerkleProof.verify(proof, c.merkleRoot, leaf), "invalid proof");

        hasClaimed[campaignId][msg.sender] = true;
        c.gdClaimed += amount;
        require(c.gdClaimed <= c.gdPool, "exceeds pool");
        GDOLLAR.safeTransfer(msg.sender, amount);
        emit Claimed(campaignId, msg.sender, amount);
    }

    function withdrawUnclaimed(uint256 campaignId) external nonReentrant {
        Campaign storage c = campaigns[campaignId];
        require(msg.sender == c.project, "only campaign owner");
        require(block.timestamp > c.claimDeadline, "claim window still open");
        uint256 remaining = c.gdPool - c.gdClaimed;
        require(remaining > 0, "nothing left to withdraw");
        c.gdClaimed = c.gdPool;
        GDOLLAR.safeTransfer(c.project, remaining);
        emit UnclaimedWithdrawn(campaignId, remaining);
    }

    function setIdentityRegistry(address _identityRegistry) external onlyOwner {
        identityRegistry = IGoodDollarIdentity(_identityRegistry);
    }
}