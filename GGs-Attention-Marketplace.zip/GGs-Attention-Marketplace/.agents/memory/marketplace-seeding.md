---
name: Marketplace seed initialization
description: Why the demo seed path is guarded against concurrent first requests.
---

Demo data initialization must be single-flight when the database starts empty.

**Why:** The overview and campaign list load in parallel, so a simple empty-table check can race and insert duplicate starter rows.

**How to apply:** Keep the seed guard as a shared in-process promise and only seed when the database has no campaigns; never rely on request ordering.