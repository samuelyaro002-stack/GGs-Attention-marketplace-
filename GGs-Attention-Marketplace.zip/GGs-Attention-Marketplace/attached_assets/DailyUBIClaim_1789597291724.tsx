/**
 * DailyUBIClaim.tsx
 *
 * Lets a verified, unique human claim their daily G$ Universal Basic Income
 * directly from GoodDollar's own UBI scheme — this is GoodDollar's UBI pool,
 * not GG's reward pool. GG's role here is just giving creators an easy way
 * to claim it without leaving the platform.
 *
 * Built against @goodsdks/citizen-sdk (current, actively maintained SDK —
 * this supersedes the older @gooddollar/web3sdk-v2 package you may see
 * referenced in older tutorials).
 *
 * Install:
 *   npm install @goodsdks/citizen-sdk wagmi viem
 *
 * NOTE: this package is under active development (GoodDollar's own docs flag
 * some method signatures as still being finalized). Before shipping, check
 * the current README at https://github.com/GoodDollar/GoodSDKs for any
 * signature changes against what's used below.
 *
 * Requires Wagmi already configured in your app (WagmiProvider + a connected
 * wallet), since this relies on useAccount / usePublicClient / useWalletClient.
 */

import { useEffect, useState, useCallback } from "react";
import { useAccount, usePublicClient, useWalletClient } from "wagmi";
import { useIdentitySDK } from "@goodsdks/identity-sdk/wagmi-sdk";
import { ClaimSDK } from "@goodsdks/identity-sdk/viem-claim-sdk";

// 42220 = Celo mainnet, 122 = Fuse mainnet. Match whichever chain your app is
// primarily connected to — Celo is recommended given deeper G$ liquidity
// and where GG's own reward-pool contract should also live.
const CHAIN_ID = 42220;

type ClaimStatus =
  | "loading"
  | "not_connected"
  | "not_verified"
  | "eligible"
  | "already_claimed"
  | "claiming"
  | "error";

export function DailyUBIClaim() {
  const { address, isConnected } = useAccount();
  const publicClient = usePublicClient();
  const { data: walletClient } = useWalletClient();
  const identitySDK = useIdentitySDK("production");

  const [status, setStatus] = useState<ClaimStatus>("loading");
  const [entitlement, setEntitlement] = useState<bigint>(0n);
  const [nextClaimTime, setNextClaimTime] = useState<Date | null>(null);
  const [errorMsg, setErrorMsg] = useState<string>("");

  const claimSDK =
    address && publicClient && walletClient && identitySDK
      ? new ClaimSDK({
          account: address,
          publicClient,
          walletClient,
          identitySDK,
          env: "production",
        })
      : null;

  const refreshStatus = useCallback(async () => {
    if (!isConnected || !address) {
      setStatus("not_connected");
      return;
    }
    if (!identitySDK || !claimSDK) {
      setStatus("loading");
      return;
    }

    try {
      // getWhitelistedRoot confirms this wallet has passed GoodDollar's
      // face-verification (proof of unique personhood).
      const { isWhitelisted } = await identitySDK.getWhitelistedRoot(address);
      if (!isWhitelisted) {
        setStatus("not_verified");
        return;
      }

      const claimAmount = await claimSDK.checkEntitlement();
      setEntitlement(claimAmount);

      if (claimAmount > 0n) {
        setStatus("eligible");
      } else {
        setStatus("already_claimed");
        const next = await claimSDK.nextClaimTime();
        setNextClaimTime(next);
      }
    } catch (err) {
      console.error("UBI status check failed:", err);
      setErrorMsg("Could not check your claim status. Try again shortly.");
      setStatus("error");
    }
  }, [isConnected, address, identitySDK, claimSDK]);

  useEffect(() => {
    refreshStatus();
  }, [refreshStatus]);

  // Sends the user into GoodDollar's face-verification flow. This opens
  // GoodDollar's own verification UI — GG's never handles biometric data
  // directly, which keeps this simple and avoids a whole separate compliance
  // surface for you.
  const startVerification = async () => {
    if (!identitySDK) return;
    try {
      const link = await identitySDK.generateFVLink(
        false, // popupMode
        window.location.href, // callbackUrl — return here after verification
        CHAIN_ID,
      );
      window.location.href = link;
    } catch (err) {
      console.error("Could not start verification:", err);
      setErrorMsg("Could not start identity verification. Try again shortly.");
      setStatus("error");
    }
  };

  const handleClaim = async () => {
    if (!claimSDK) return;
    setStatus("claiming");
    try {
      await claimSDK.claim();
      await refreshStatus();
    } catch (err) {
      console.error("Claim failed:", err);
      setErrorMsg("Claim didn't go through. Try again shortly.");
      setStatus("error");
    }
  };

  return (
    <div className="ubi-claim-card">
      <h3>Daily G$ basic income</h3>

      {status === "not_connected" && <p>Connect your wallet to check eligibility.</p>}

      {status === "loading" && <p>Checking your status.</p>}

      {status === "not_verified" && (
        <>
          <p>Verify you're a unique human to unlock daily G$ claims.</p>
          <button onClick={startVerification}>Verify with GoodDollar</button>
        </>
      )}

      {status === "eligible" && (
        <>
          <p>You can claim {entitlement.toString()} G$ today.</p>
          <button onClick={handleClaim}>Claim now</button>
        </>
      )}

      {status === "claiming" && <p>Submitting your claim.</p>}

      {status === "already_claimed" && (
        <p>
          Already claimed today.
          {nextClaimTime ? ` Next claim opens ${nextClaimTime.toLocaleString()}.` : ""}
        </p>
      )}

      {status === "error" && (
        <>
          <p>{errorMsg}</p>
          <button onClick={refreshStatus}>Retry</button>
        </>
      )}
    </div>
  );
}
