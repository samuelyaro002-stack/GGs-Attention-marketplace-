# Security Hardening Guide — GG's Backend

Honest framing first: nobody can promise zero mistakes, especially code
written sight-unseen of your actual Replit backend. What I can give you is a
set of well-established, load-bearing patterns that close the most common
holes in a project like this. Treat this as a checklist to implement and
verify, not a guarantee — get a second pair of eyes (or a proper security
review) before real user funds or data go through it.

Examples below use Node/Express, the most common Replit backend stack. If
you're on something else (Next.js API routes, Python/Flask, etc.), the
*principles* are identical — ask me for the equivalent in your actual stack
and I'll translate this directly.

## 1. API keys — never in code, never in the frontend
```js
// .env (never committed — add to .gitignore)
X_API_BEARER_TOKEN=xxxxx
GOODDOLLAR_ENV=production
SESSION_SECRET=xxxxx

// server.js
require('dotenv').config();
const xApiToken = process.env.X_API_BEARER_TOKEN;
```
- In Replit specifically: use the **Secrets** tool (padlock icon), not a
  `.env` file committed to your repo. Replit injects these as environment
  variables automatically.
- Any call to X/TikTok/Medium APIs happens **server-side only**. The browser
  never sees these keys. If your frontend needs engagement data, it calls
  *your* backend, and your backend calls the platform API.

## 2. Admin routes — require real authentication, not a hidden URL
A common mistake: assuming `/admin/publish-root` is "safe" because nobody
knows the URL. That's not protection — it's obscurity, and it fails the
moment someone finds the link.
```js
function requireAdmin(req, res, next) {
  const token = req.headers.authorization?.split('Bearer ')[1];
  if (!token) return res.status(401).json({ error: 'Missing token' });

  try {
    const payload = jwt.verify(token, process.env.SESSION_SECRET);
    if (payload.role !== 'admin') {
      return res.status(403).json({ error: 'Not authorized' });
    }
    req.user = payload;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

app.post('/admin/publish-root', requireAdmin, publishRootHandler);
app.post('/admin/finalize-swap', requireAdmin, finalizeSwapHandler);
```
- Every admin-only route gets this middleware. Don't rely on frontend
  routing (hiding a button) to gate access — the API endpoint itself must
  check, since anyone can call it directly.
- Rate-limit admin routes too (see section 5) — a token that leaks shouldn't
  give unlimited calls.

## 3. Authentication for regular users (wallet-based)
Since users already connect a wallet, use **Sign-In With Ethereum (SIWE)**
style auth instead of building a password system from scratch:
```js
// 1. Backend issues a nonce
app.get('/auth/nonce', (req, res) => {
  const nonce = crypto.randomBytes(16).toString('hex');
  req.session.nonce = nonce;
  res.json({ nonce });
});

// 2. User signs a message containing the nonce with their wallet
// 3. Backend verifies the signature matches the claimed address
const { verifyMessage } = require('viem');
app.post('/auth/verify', async (req, res) => {
  const { address, signature, message } = req.body;
  const valid = await verifyMessage({ address, message, signature });
  if (!valid || !message.includes(req.session.nonce)) {
    return res.status(401).json({ error: 'Verification failed' });
  }
  req.session.address = address;
  const token = jwt.sign({ address, role: 'user' }, process.env.SESSION_SECRET, { expiresIn: '24h' });
  res.json({ token });
});
```
This proves wallet ownership without ever handling a password.

## 4. XSS protection
Two layers, both matter:
- **Escape on render** — the demo's `esc()` function is the right idea for
  raw HTML string building. If you move to React on Replit, React escapes by
  default *unless* you use `dangerouslySetInnerHTML` — avoid that entirely
  for anything user-submitted (campaign briefs, handles, etc.).
- **Sanitize on input**, server-side, before storing:
```js
const sanitizeHtml = require('sanitize-html');
const cleanBrief = sanitizeHtml(req.body.brief, { allowedTags: [], allowedAttributes: {} });
```
Never trust frontend validation alone — always re-validate and sanitize
server-side, since a request can bypass your frontend entirely.

## 5. Sanitize and validate every form input server-side
```js
const { body, validationResult } = require('express-validator');

app.post('/campaigns',
  body('name').trim().isLength({ min: 1, max: 80 }).escape(),
  body('brief').trim().isLength({ max: 400 }),
  body('pool').isFloat({ min: 1, max: 10000000 }),
  body('link').isURL(),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    // proceed
  }
);
```
Add rate limiting on top, especially on submission endpoints (creators could
otherwise spam-submit for the leaderboard):
```js
const rateLimit = require('express-rate-limit');
const submitLimiter = rateLimit({ windowMs: 60 * 1000, max: 5 });
app.post('/submissions', submitLimiter, /* ... */);
```

## 6. A few more that get skipped and shouldn't
- **CORS**: lock `Access-Control-Allow-Origin` to your actual frontend
  domain, not `*`.
- **Helmet**: `app.use(require('helmet')())` — sets a batch of sensible
  security headers in one line.
- **HTTPS only** in production; Replit deployments give you this by default,
  don't disable it.
- **Never log secrets** — double-check console.log statements before they
  ship, a stray `console.log(apiKey)` in a public Replit is a real leak.
- **Least privilege on any database/service credentials** — the backend's
  DB user shouldn't have permissions beyond what it actually needs.

## What this doesn't cover
This is web-app security. The smart contract's security (reentrancy,
slippage, access control) is a separate concern already flagged in
`DEPLOYMENT-NOTES.md` and `GDOLLAR-INTEGRATION-NOTES.md` — an audit there is
still non-negotiable before real funds move through it, regardless of how
solid the backend is.
