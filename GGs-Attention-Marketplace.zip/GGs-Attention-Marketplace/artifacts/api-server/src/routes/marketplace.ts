import { Router, type IRouter } from "express";
import { desc, eq } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  campaignsTable,
  type Campaign,
  type Submission,
  submissionsTable,
} from "@workspace/db";
import {
  CreateCampaignBody,
  CreateCampaignResponse,
  CreateSubmissionBody,
  CreateSubmissionParams,
  CreateSubmissionResponse,
  GetCampaignLeaderboardParams,
  GetCampaignLeaderboardResponse,
  GetCampaignParams,
  GetCampaignResponse,
  GetMarketplaceSummaryResponse,
  GetRewardPoolClaimParams,
  GetRewardPoolClaimResponse,
  GetRewardPoolDistributionParams,
  GetRewardPoolDistributionResponse,
  GetRewardPoolConfigResponse,
  ListCampaignsResponse,
  RecordRewardPoolClaimBody,
  RecordRewardPoolClaimParams,
  RecordRewardPoolClaimResponse,
  RecordRewardPoolFundingBody,
  RecordRewardPoolFundingParams,
  RecordRewardPoolFundingResponse,
  RecordRewardPoolRootBody,
  RecordRewardPoolRootParams,
  RecordRewardPoolRootResponse,
  RecordRewardPoolSwapBody,
  RecordRewardPoolSwapParams,
  RecordRewardPoolSwapResponse,
  type Campaign as ApiCampaign,
  type LeaderboardRow,
} from "@workspace/api-zod";
import {
  GDOLLAR_TOKEN_ADDRESS,
  REWARD_POOL_CHAIN_ID,
  REWARD_POOL_CHAIN_NAME,
  REWARD_POOL_CONTRACT_ADDRESS,
  buildRewardDistribution,
  getRewardClaim,
} from "../reward-pool";

const router: IRouter = Router();

let seeded = false;
let seedPromise: Promise<void> | null = null;

const accountTrust: Record<string, number> = {
  "under-30-days": 0.65,
  "1-6-months": 0.85,
  established: 1,
};

function hashString(value: string): number {
  let hash = 0;
  for (let index = 0; index < value.length; index += 1) {
    hash = (hash << 5) - hash + value.charCodeAt(index);
    hash |= 0;
  }
  return Math.abs(hash);
}

function simulatedEngagement(seed: string) {
  const hash = hashString(seed);
  const likes = 120 + (hash % 320);
  const reposts = 12 + ((hash >> 4) % 82);
  const replies = 8 + ((hash >> 8) % 52);
  return { likes, reposts, replies };
}

async function ensureSeeded(): Promise<void> {
  if (seeded) return;
  if (seedPromise) {
    await seedPromise;
    return;
  }

  seedPromise = seedMarketplace();
  try {
    await seedPromise;
  } finally {
    seedPromise = null;
  }
}

async function seedMarketplace(): Promise<void> {
  if (seeded) return;

  const existing = await db
    .select({ id: campaignsTable.id })
    .from(campaignsTable)
    .limit(1);

  if (existing.length === 0) {
    const [kora, arc] = await db
      .insert(campaignsTable)
      .values([
        {
          name: "Kora Protocol",
          brief:
            "Make cross-chain swaps feel simple. Tell the story of a faster, friendlier DeFi experience.",
          pool: 5000,
          cycle: "2 weeks",
        },
        {
          name: "Arcade Labs",
          brief:
            "Bring more builders into the open-source gaming ecosystem with practical, high-signal content.",
          pool: 2800,
          cycle: "1 week",
        },
      ])
      .returning();

    const firstSubmissions = [
      {
        campaignId: kora.id,
        handle: "@chainmaven",
        platform: "X (Twitter)",
        link: "https://x.com/chainmaven/status/184001",
        accountAge: "established",
        likes: 412,
        reposts: 86,
        replies: 38,
        trust: 1,
        xp: 698,
      },
      {
        campaignId: kora.id,
        handle: "@web3nana",
        platform: "X (Twitter)",
        link: "https://x.com/web3nana/status/184002",
        accountAge: "1-6-months",
        likes: 284,
        reposts: 54,
        replies: 21,
        trust: 0.85,
        xp: 443,
      },
      {
        campaignId: arc.id,
        handle: "@buildwithtomi",
        platform: "TikTok",
        link: "https://tiktok.com/@buildwithtomi/video/184003",
        accountAge: "established",
        likes: 338,
        reposts: 41,
        replies: 29,
        trust: 1,
        xp: 537,
      },
    ];

    await db.insert(submissionsTable).values(firstSubmissions);
  }

  seeded = true;
}

async function getSubmissions(campaignId?: number): Promise<Submission[]> {
  if (campaignId === undefined) {
    return db
      .select()
      .from(submissionsTable)
      .orderBy(desc(submissionsTable.createdAt));
  }

  return db
    .select()
    .from(submissionsTable)
    .where(eq(submissionsTable.campaignId, campaignId))
    .orderBy(desc(submissionsTable.createdAt));
}

function serializeCampaign(
  campaign: Campaign,
  submissions: Submission[],
): ApiCampaign {
  return {
    id: campaign.id,
    name: campaign.name,
    brief: campaign.brief,
    pool: campaign.pool,
    cycle: campaign.cycle,
    submissionsCount: submissions.length,
    xpAwarded: submissions.reduce((total, submission) => total + submission.xp, 0),
    createdAt: campaign.createdAt,
    rewardAsset: "G$",
    chainId: campaign.chainId,
    contractAddress: campaign.contractAddress,
    projectWallet: campaign.projectWallet,
    onchainCampaignId: campaign.onchainCampaignId,
    ethFundedRaw: campaign.ethFundedRaw,
    gdPoolRaw: campaign.gdPoolRaw,
    merkleRoot: campaign.merkleRoot,
    rewardStatus: campaign.rewardStatus as ApiCampaign["rewardStatus"],
    claimDeadline: campaign.claimDeadline,
  };
}

async function getCampaignById(id: number): Promise<Campaign | undefined> {
  const [campaign] = await db
    .select()
    .from(campaignsTable)
    .where(eq(campaignsTable.id, id));
  return campaign;
}

async function leaderboardFor(
  campaign: Campaign,
  submissions: Submission[],
): Promise<LeaderboardRow[]> {
  const byHandle = new Map<
    string,
    {
      handle: string;
      platform: string;
      posts: number;
      xp: number;
      trust: number;
    }
  >();

  for (const submission of submissions) {
    const existing = byHandle.get(submission.handle);
    if (existing) {
      existing.posts += 1;
      existing.xp += submission.xp;
      existing.trust = Math.max(existing.trust, submission.trust);
    } else {
      byHandle.set(submission.handle, {
        handle: submission.handle,
        platform: submission.platform,
        posts: 1,
        xp: submission.xp,
        trust: submission.trust,
      });
    }
  }

  const rows = Array.from(byHandle.values()).sort((a, b) => b.xp - a.xp);
  const totalXp = rows.reduce((total, row) => total + row.xp, 0) || 1;

  return rows.map((row, index) => ({
    rank: index + 1,
    handle: row.handle,
    platform: row.platform,
    posts: row.posts,
    xp: row.xp,
    share: row.xp / totalXp,
    estimatedReward: (row.xp / totalXp) * campaign.pool,
    trust: row.trust,
  }));
}

router.get("/marketplace/summary", async (_req, res): Promise<void> => {
  await ensureSeeded();
  const campaigns = await db
    .select()
    .from(campaignsTable)
    .orderBy(desc(campaignsTable.createdAt));
  const submissions = await getSubmissions();
  const creators = new Set(submissions.map((submission) => submission.handle));
  const campaignById = new Map(campaigns.map((campaign) => [campaign.id, campaign]));

  const recentActivity = [
    ...campaigns.map((campaign) => ({
      kind: "campaign",
      label: campaign.name,
      detail: `New campaign launched · $${campaign.pool.toLocaleString()} reward pool`,
      createdAt: campaign.createdAt,
    })),
    ...submissions.map((submission) => ({
      kind: "submission",
      label: submission.handle,
      detail: `Earned ${submission.xp.toLocaleString()} XP in ${
        campaignById.get(submission.campaignId)?.name ?? "a campaign"
      }`,
      createdAt: submission.createdAt,
    })),
  ]
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, 5);

  const data = {
    activeCampaigns: campaigns.length,
    creatorsSubmitted: creators.size,
    totalXp: submissions.reduce((total, submission) => total + submission.xp, 0),
    totalPool: campaigns.reduce((total, campaign) => total + campaign.pool, 0),
    recentActivity,
  };

  res.json(GetMarketplaceSummaryResponse.parse(data));
});

router.get("/reward-pool/config", (_req, res): void => {
  res.json(
    GetRewardPoolConfigResponse.parse({
      chainId: REWARD_POOL_CHAIN_ID,
      chainName: REWARD_POOL_CHAIN_NAME,
      tokenAddress: GDOLLAR_TOKEN_ADDRESS,
      contractAddress: REWARD_POOL_CONTRACT_ADDRESS,
      ready: REWARD_POOL_CONTRACT_ADDRESS !== null,
    }),
  );
});

router.get("/campaigns", async (_req, res): Promise<void> => {
  await ensureSeeded();
  const campaigns = await db
    .select()
    .from(campaignsTable)
    .orderBy(desc(campaignsTable.createdAt));
  const submissions = await getSubmissions();
  const submissionsByCampaign = new Map<number, Submission[]>();

  for (const submission of submissions) {
    const current = submissionsByCampaign.get(submission.campaignId) ?? [];
    current.push(submission);
    submissionsByCampaign.set(submission.campaignId, current);
  }

  res.json(
    ListCampaignsResponse.parse(
      campaigns.map((campaign) =>
        serializeCampaign(campaign, submissionsByCampaign.get(campaign.id) ?? []),
      ),
    ),
  );
});

router.post("/campaigns", async (req, res): Promise<void> => {
  const parsed = CreateCampaignBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [campaign] = await db
    .insert(campaignsTable)
    .values({
      name: parsed.data.name,
      brief: parsed.data.brief ?? "",
      pool: parsed.data.pool,
      cycle: parsed.data.cycle,
    })
    .returning();

  res.status(201).json(
    CreateCampaignResponse.parse(serializeCampaign(campaign, [])),
  );
});

router.get("/campaigns/:campaignId", async (req, res): Promise<void> => {
  const params = GetCampaignParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await ensureSeeded();
  const campaign = await getCampaignById(params.data.campaignId);
  if (!campaign) {
    res.status(404).json({ error: "Campaign not found" });
    return;
  }

  const submissions = await getSubmissions(campaign.id);
  res.json(
    GetCampaignResponse.parse({
      ...serializeCampaign(campaign, submissions),
      submissions,
    }),
  );
});

router.post(
  "/campaigns/:campaignId/submissions",
  async (req, res): Promise<void> => {
    const params = CreateSubmissionParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }

    const parsed = CreateSubmissionBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: parsed.error.message });
      return;
    }

    await ensureSeeded();
    const campaign = await getCampaignById(params.data.campaignId);
    if (!campaign) {
      res.status(404).json({ error: "Campaign not found" });
      return;
    }

    const trust = accountTrust[parsed.data.accountAge];
    const engagement = simulatedEngagement(
      `${campaign.id}:${parsed.data.handle}:${parsed.data.link}`,
    );
    const xp = Math.round(
      (engagement.likes + engagement.reposts * 3 + engagement.replies * 2) *
        trust,
    );

    const [submission] = await db
      .insert(submissionsTable)
      .values({
        campaignId: campaign.id,
        handle: parsed.data.handle,
        platform: parsed.data.platform,
        link: parsed.data.link,
        walletAddress: parsed.data.walletAddress ?? null,
        accountAge: parsed.data.accountAge,
        ...engagement,
        trust,
        xp,
      })
      .returning();

    res.status(201).json(CreateSubmissionResponse.parse(submission));
  },
);

router.get(
  "/campaigns/:campaignId/leaderboard",
  async (req, res): Promise<void> => {
    const params = GetCampaignLeaderboardParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: params.error.message });
      return;
    }

    await ensureSeeded();
    const campaign = await getCampaignById(params.data.campaignId);
    if (!campaign) {
      res.status(404).json({ error: "Campaign not found" });
      return;
    }

    const submissions = await getSubmissions(campaign.id);
    res.json(
      GetCampaignLeaderboardResponse.parse(
        await leaderboardFor(campaign, submissions),
      ),
    );
  },
);

function rewardInputs(submissions: Submission[]) {
  return submissions.map((submission) => ({
    walletAddress: submission.walletAddress ?? "",
    handle: submission.handle,
    xp: submission.xp,
  }));
}

async function distributionForCampaign(campaign: Campaign) {
  if (campaign.onchainCampaignId === null) {
    throw new Error("Record the onchain campaign funding before building a root");
  }

  const submissions = await getSubmissions(campaign.id);
  return buildRewardDistribution(
    campaign.onchainCampaignId,
    campaign.gdPoolRaw,
    rewardInputs(submissions),
  );
}

router.post(
  "/campaigns/:campaignId/reward-pool/funding",
  async (req, res): Promise<void> => {
    const params = RecordRewardPoolFundingParams.safeParse(req.params);
    const parsed = RecordRewardPoolFundingBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: "Invalid reward pool funding data" });
      return;
    }

    const campaign = await getCampaignById(params.data.campaignId);
    if (!campaign) {
      res.status(404).json({ error: "Campaign not found" });
      return;
    }

    const [updatedCampaign] = await db
      .update(campaignsTable)
      .set({
        chainId: REWARD_POOL_CHAIN_ID,
        contractAddress: parsed.data.contractAddress,
        projectWallet: parsed.data.projectWallet,
        onchainCampaignId: parsed.data.onchainCampaignId,
        ethFundedRaw: parsed.data.ethFundedRaw,
        fundingTxHash: parsed.data.txHash,
        rewardStatus: "funded",
      })
      .where(eq(campaignsTable.id, campaign.id))
      .returning();

    const submissions = await getSubmissions(campaign.id);
    res.json(
      RecordRewardPoolFundingResponse.parse(
        serializeCampaign(updatedCampaign, submissions),
      ),
    );
  },
);

router.post(
  "/campaigns/:campaignId/reward-pool/swap",
  async (req, res): Promise<void> => {
    const params = RecordRewardPoolSwapParams.safeParse(req.params);
    const parsed = RecordRewardPoolSwapBody.safeParse(req.body);
    if (!params.success || !parsed.success || !/^[0-9]+$/.test(parsed.data.gdPoolRaw)) {
      res.status(400).json({ error: "Invalid reward pool swap data" });
      return;
    }

    const campaign = await getCampaignById(params.data.campaignId);
    if (!campaign) {
      res.status(404).json({ error: "Campaign not found" });
      return;
    }
    if (campaign.onchainCampaignId === null) {
      res.status(400).json({ error: "Record funding before recording the swap" });
      return;
    }

    const [updatedCampaign] = await db
      .update(campaignsTable)
      .set({
        gdPoolRaw: parsed.data.gdPoolRaw,
        swapTxHash: parsed.data.txHash,
        rewardStatus: "swapped",
      })
      .where(eq(campaignsTable.id, campaign.id))
      .returning();

    const submissions = await getSubmissions(campaign.id);
    res.json(
      RecordRewardPoolSwapResponse.parse(
        serializeCampaign(updatedCampaign, submissions),
      ),
    );
  },
);

router.get(
  "/campaigns/:campaignId/reward-pool/distribution",
  async (req, res): Promise<void> => {
    const params = GetRewardPoolDistributionParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: "Invalid campaign id" });
      return;
    }

    const campaign = await getCampaignById(params.data.campaignId);
    if (!campaign) {
      res.status(404).json({ error: "Campaign not found" });
      return;
    }

    try {
      const distribution = await distributionForCampaign(campaign);
      res.json(
        GetRewardPoolDistributionResponse.parse({
          campaignId: campaign.id,
          onchainCampaignId: campaign.onchainCampaignId,
          gdPoolRaw: campaign.gdPoolRaw,
          totalAllocatedRaw: distribution.totalAllocatedRaw,
          merkleRoot: distribution.root,
          leaves: distribution.leaves,
        }),
      );
    } catch (error) {
      res.status(400).json({
        error: error instanceof Error ? error.message : "Unable to build distribution",
      });
    }
  },
);

router.post(
  "/campaigns/:campaignId/reward-pool/root",
  async (req, res): Promise<void> => {
    const params = RecordRewardPoolRootParams.safeParse(req.params);
    const parsed = RecordRewardPoolRootBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: "Invalid Merkle root data" });
      return;
    }

    const campaign = await getCampaignById(params.data.campaignId);
    if (!campaign) {
      res.status(404).json({ error: "Campaign not found" });
      return;
    }

    try {
      const distribution = await distributionForCampaign(campaign);
      if (distribution.root.toLowerCase() !== parsed.data.merkleRoot.toLowerCase()) {
        res.status(400).json({ error: "Merkle root does not match current XP shares" });
        return;
      }

      const [updatedCampaign] = await db
        .update(campaignsTable)
        .set({
          merkleRoot: parsed.data.merkleRoot,
          rootTxHash: parsed.data.txHash,
          rewardStatus: "root-published",
        })
        .where(eq(campaignsTable.id, campaign.id))
        .returning();
      const submissions = await getSubmissions(campaign.id);
      res.json(
        RecordRewardPoolRootResponse.parse(
          serializeCampaign(updatedCampaign, submissions),
        ),
      );
    } catch (error) {
      res.status(400).json({
        error: error instanceof Error ? error.message : "Unable to publish root",
      });
    }
  },
);

router.get(
  "/campaigns/:campaignId/reward-pool/claim/:walletAddress",
  async (req, res): Promise<void> => {
    const params = GetRewardPoolClaimParams.safeParse(req.params);
    if (!params.success) {
      res.status(400).json({ error: "Invalid campaign or wallet address" });
      return;
    }
    const campaign = await getCampaignById(params.data.campaignId);
    if (!campaign) {
      res.status(404).json({ error: "Campaign not found" });
      return;
    }
    if (campaign.onchainCampaignId === null || !campaign.merkleRoot) {
      res.status(400).json({ error: "The campaign root has not been published" });
      return;
    }

    try {
      const submissions = await getSubmissions(campaign.id);
      const claim = getRewardClaim(
        campaign.onchainCampaignId,
        campaign.gdPoolRaw,
        campaign.merkleRoot,
        rewardInputs(submissions),
        params.data.walletAddress,
      );
      res.json(
        GetRewardPoolClaimResponse.parse({
          campaignId: campaign.id,
          onchainCampaignId: campaign.onchainCampaignId,
          ...claim,
        }),
      );
    } catch (error) {
      res.status(404).json({
        error: error instanceof Error ? error.message : "No claim found",
      });
    }
  },
);

router.post(
  "/campaigns/:campaignId/reward-pool/claim",
  async (req, res): Promise<void> => {
    const params = RecordRewardPoolClaimParams.safeParse(req.params);
    const parsed = RecordRewardPoolClaimBody.safeParse(req.body);
    if (!params.success || !parsed.success) {
      res.status(400).json({ error: "Invalid claim data" });
      return;
    }
    const campaign = await getCampaignById(params.data.campaignId);
    if (!campaign) {
      res.status(404).json({ error: "Campaign not found" });
      return;
    }
    if (campaign.onchainCampaignId === null || !campaign.merkleRoot) {
      res.status(400).json({ error: "The campaign root has not been published" });
      return;
    }

    try {
      const submissions = await getSubmissions(campaign.id);
      const claim = getRewardClaim(
        campaign.onchainCampaignId,
        campaign.gdPoolRaw,
        campaign.merkleRoot,
        rewardInputs(submissions),
        parsed.data.walletAddress,
      );
      if (claim.amountRaw !== parsed.data.amountRaw) {
        res.status(400).json({ error: "Claim amount does not match the published root" });
        return;
      }

      await db
        .update(campaignsTable)
        .set({ rewardStatus: "claiming" })
        .where(eq(campaignsTable.id, campaign.id));

      res.json(
        RecordRewardPoolClaimResponse.parse({
          campaignId: campaign.id,
          onchainCampaignId: campaign.onchainCampaignId,
          ...claim,
        }),
      );
    } catch (error) {
      res.status(400).json({
        error: error instanceof Error ? error.message : "Unable to record claim",
      });
    }
  },
);

export default router;