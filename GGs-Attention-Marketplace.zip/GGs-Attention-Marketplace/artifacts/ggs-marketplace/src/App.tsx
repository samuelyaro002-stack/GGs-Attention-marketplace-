import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { Link, Route, Switch, useLocation, useParams, Router as WouterRouter } from 'wouter';
import { z } from 'zod';
import { parseEther } from 'viem';
import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  CircleDollarSign,
  ExternalLink,
  FileText,
  LayoutDashboard,
  Menu,
  Plus,
  Radar,
  Send,
  Sparkles,
  Trophy,
  Users,
  X,
  Zap,
} from 'lucide-react';
import {
  getGetCampaignLeaderboardQueryKey,
  getGetCampaignQueryKey,
  getGetMarketplaceSummaryQueryKey,
  getGetRewardPoolClaimQueryKey,
  getGetRewardPoolDistributionQueryKey,
  getListCampaignsQueryKey,
  SubmissionInputAccountAge,
  SubmissionInputPlatform,
  useCreateCampaign,
  useCreateSubmission,
  useGetCampaign,
  useGetCampaignLeaderboard,
  useGetRewardPoolClaim,
  useGetRewardPoolConfig,
  useGetRewardPoolDistribution,
  useGetMarketplaceSummary,
  useListCampaigns,
  useRecordRewardPoolClaim,
  useRecordRewardPoolFunding,
  useRecordRewardPoolRoot,
  useRecordRewardPoolSwap,
  type Campaign,
  type CampaignInput,
  type LeaderboardRow,
  type Submission,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  CLAIM_WINDOW_SECONDS,
  REWARD_POOL_CONTRACT_ADDRESS,
  claimOnchainReward,
  connectWallet,
  createOnchainCampaign,
  finalizeOnchainSwap,
  isRewardPoolConfigured,
  publishOnchainRoot,
} from '@/lib/reward-pool';

const queryClient = new QueryClient();

const campaignSchema = z.object({
  name: z.string().min(2, 'Give the campaign a name.').max(80),
  brief: z.string().max(500).optional(),
  pool: z.coerce.number().positive('Pool must be greater than 0.'),
  cycle: z.enum(['1 week', '2 weeks', '4 weeks']),
});
type CampaignFormValues = z.infer<typeof campaignSchema>;

const submissionSchema = z.object({
  campaignId: z.coerce.number().positive('Choose a campaign.'),
  handle: z.string().min(2, 'Enter your creator handle.').max(80),
  platform: z.enum(['X (Twitter)', 'TikTok', 'Medium']),
  link: z.string().url('Paste a valid post URL.'),
  accountAge: z.enum(['under-30-days', '1-6-months', 'established']),
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/, 'Connect a valid EVM wallet to claim G$.'),
});
type SubmissionFormValues = z.infer<typeof submissionSchema>;

const money = (value: number | undefined) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value ?? 0);
const number = (value: number | undefined) => new Intl.NumberFormat('en-US').format(value ?? 0);
const dateLabel = (value: string | undefined) =>
  value ? new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(new Date(value)) : 'Recently';

function BrandMark({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-3" data-testid="link-brand">
      <span className="relative grid size-9 place-items-center rounded-sm bg-primary text-primary-foreground transition-transform group-hover:-rotate-6">
        <span className="absolute size-3 rotate-45 border-2 border-current" />
        <span className="absolute h-4 w-0.5 bg-current" />
      </span>
      {!compact && <span className="text-[15px] font-bold tracking-[-0.03em]">GG<span className="text-primary">.</span>ATTENTION</span>}
    </Link>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const nav = [
    { href: '/', label: 'Overview', icon: LayoutDashboard },
    { href: '/projects', label: 'Projects', icon: BriefcaseBusiness },
    { href: '/creators', label: 'Creators', icon: Users },
    { href: '/leaderboard', label: 'Leaderboard', icon: Trophy },
  ];
  return (
    <div className="grain min-h-[100dvh] bg-background text-foreground">
      <header className="sticky top-0 z-20 border-b border-border/70 bg-background/90 backdrop-blur-md">
        <div className="mx-auto flex h-[68px] max-w-[1440px] items-center justify-between px-5 lg:px-10">
          <BrandMark />
          <nav className="hidden items-center gap-1 md:flex" aria-label="Main navigation">
            {nav.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                data-testid={`link-nav-${label.toLowerCase()}`}
                className={`flex items-center gap-2 rounded-sm px-4 py-2 text-sm font-medium transition-colors ${
                  location === href ? 'bg-foreground text-background' : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <Icon size={15} strokeWidth={1.8} />
                {label}
              </Link>
            ))}
          </nav>
          <div className="hidden items-center gap-3 md:flex">
            <span className="flex items-center gap-2 text-[11px] font-medium uppercase tracking-[.14em] text-muted-foreground">
              <span className="live-dot size-2 rounded-full bg-secondary" /> Network live
            </span>
            <Button asChild size="sm" data-testid="button-launch-header">
              <Link href="/projects">Launch campaign <ArrowUpRight size={14} /></Link>
            </Button>
          </div>
          <button
            type="button"
            onClick={() => setMobileOpen((open) => !open)}
            className="grid size-9 place-items-center rounded-sm border border-border md:hidden"
            data-testid="button-toggle-menu"
            aria-label="Toggle navigation"
          >
            {mobileOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
        {mobileOpen && (
          <div className="border-t border-border bg-card px-5 py-3 md:hidden">
            {nav.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                onClick={() => setMobileOpen(false)}
                data-testid={`link-mobile-${label.toLowerCase()}`}
                className={`flex items-center gap-3 border-b border-border/70 py-3 text-sm font-medium last:border-0 ${
                  location === href ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                <Icon size={16} /> {label}
              </Link>
            ))}
          </div>
        )}
      </header>
      <main className="mx-auto max-w-[1440px] px-5 py-8 lg:px-10 lg:py-12">{children}</main>
      <footer className="mx-auto flex max-w-[1440px] flex-col gap-3 border-t border-border/70 px-5 py-8 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between lg:px-10">
        <span className="font-mono tracking-tight">GG / ATTENTION MARKETPLACE</span>
        <span>Real engagement, earned in the open.</span>
      </footer>
    </div>
  );
}

function PageIntro({ eyebrow, title, description, action }: { eyebrow: string; title: ReactNode; description: string; action?: ReactNode }) {
  return (
    <div className="mb-9 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
      <div className="enter-up max-w-2xl">
        <p className="mb-3 flex items-center gap-2 font-mono text-[11px] uppercase tracking-[.18em] text-primary">
          <span className="h-px w-6 bg-primary" /> {eyebrow}
        </p>
        <h1 className="text-balance text-4xl font-semibold leading-[.98] tracking-[-.055em] sm:text-5xl lg:text-[4.5rem]">{title}</h1>
        <p className="mt-5 max-w-xl text-[15px] leading-7 text-muted-foreground">{description}</p>
      </div>
      {action && <div className="enter-up enter-up-delay-1 shrink-0">{action}</div>}
    </div>
  );
}

function SkeletonBlock({ className = '' }: { className?: string }) {
  return <div className={`animate-pulse rounded-sm bg-muted ${className}`} />;
}

function QueryError({ retry }: { retry: () => void }) {
  return (
    <div className="flex flex-col items-start gap-3 rounded-sm border border-destructive/30 bg-destructive/5 p-5" data-testid="status-error">
      <p className="text-sm font-medium">The signal dropped before we could load this view.</p>
      <Button variant="outline" size="sm" onClick={retry} data-testid="button-retry">Try again</Button>
    </div>
  );
}

function Metric({ icon: Icon, label, value, accent = false }: { icon: typeof Activity; label: string; value: string; accent?: boolean }) {
  return (
    <div className={`border-l-2 py-1 pl-4 ${accent ? 'border-primary' : 'border-border'}`} data-testid={`metric-${label.toLowerCase().replaceAll(' ', '-')}`}>
      <div className="mb-2 flex items-center gap-2 text-[11px] font-medium uppercase tracking-[.14em] text-muted-foreground"><Icon size={14} /> {label}</div>
      <div className="font-mono text-2xl font-medium tracking-[-.06em] sm:text-3xl">{value}</div>
    </div>
  );
}

function Overview() {
  const summaryQuery = useGetMarketplaceSummary();
  const campaignsQuery = useListCampaigns();
  const summary = summaryQuery.data;
  const featured = useMemo(() => (campaignsQuery.data ?? []).slice(0, 3), [campaignsQuery.data]);
  return (
    <div>
      <section className="grid-paper relative overflow-hidden rounded-sm border border-border bg-card px-6 py-10 sm:px-10 lg:px-16 lg:py-16">
        <div className="absolute -right-16 -top-20 size-64 rounded-full border-[34px] border-primary/15" />
        <div className="absolute -right-4 top-20 size-20 rounded-full bg-accent/70 blur-[1px]" />
        <div className="relative max-w-4xl enter-up">
          <p className="mb-7 flex items-center gap-2 font-mono text-[11px] uppercase tracking-[.2em] text-primary"><span className="live-dot size-2 rounded-full bg-primary" /> Open attention protocol</p>
          <h1 className="max-w-4xl text-balance text-5xl font-semibold leading-[.91] tracking-[-.07em] sm:text-7xl lg:text-[7.3rem]">Attention is an asset.<br /><span className="text-primary">Put it to work.</span></h1>
          <p className="mt-8 max-w-lg text-base leading-7 text-muted-foreground sm:text-lg">A persistent onchain marketplace where real engagement earns real rewards — and every allocation stays visible.</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Button asChild size="lg" data-testid="button-explore-campaigns"><Link href="/projects">Explore campaigns <ArrowRight size={16} /></Link></Button>
            <Button asChild variant="outline" size="lg" data-testid="button-submit-as-creator"><Link href="/creators">Submit a post</Link></Button>
          </div>
        </div>
        <div className="relative mt-14 grid max-w-4xl grid-cols-2 gap-x-8 gap-y-7 border-t border-border/80 pt-7 sm:grid-cols-4 lg:mt-20">
          <Metric icon={BriefcaseBusiness} label="Active campaigns" value={summaryQuery.isLoading ? '—' : number(summary?.activeCampaigns)} accent />
          <Metric icon={Users} label="Creators in" value={summaryQuery.isLoading ? '—' : number(summary?.creatorsSubmitted)} />
          <Metric icon={Zap} label="XP awarded" value={summaryQuery.isLoading ? '—' : number(summary?.totalXp)} />
          <Metric icon={CircleDollarSign} label="In the pool" value={summaryQuery.isLoading ? '—' : money(summary?.totalPool)} />
        </div>
      </section>
      <div className="mt-14 grid gap-12 lg:grid-cols-[1fr_360px]">
        <section className="enter-up enter-up-delay-1">
          <div className="mb-5 flex items-end justify-between border-b border-border pb-4">
            <div><p className="font-mono text-[11px] uppercase tracking-[.18em] text-muted-foreground">01 / Live board</p><h2 className="mt-2 text-2xl font-semibold tracking-[-.04em]">Campaigns with momentum</h2></div>
            <Link href="/projects" className="hidden items-center gap-1 text-xs font-medium text-primary sm:flex" data-testid="link-view-all-campaigns">View all <ArrowRight size={14} /></Link>
          </div>
          {campaignsQuery.isLoading && <div className="space-y-3"><SkeletonBlock className="h-28" /><SkeletonBlock className="h-28" /></div>}
          {campaignsQuery.isError && <QueryError retry={() => void campaignsQuery.refetch()} />}
          {!campaignsQuery.isLoading && !campaignsQuery.isError && featured.length === 0 && <div className="border border-dashed border-border p-10 text-center text-sm text-muted-foreground" data-testid="empty-campaigns">No active campaigns yet. The first allocation starts here.</div>}
          <div className="space-y-3">
            {featured.map((campaign, index) => <CampaignRow key={campaign.id} campaign={campaign} index={index} />)}
          </div>
        </section>
        <section className="enter-up enter-up-delay-2">
          <div className="mb-5 border-b border-border pb-4"><p className="font-mono text-[11px] uppercase tracking-[.18em] text-muted-foreground">02 / The tape</p><h2 className="mt-2 text-2xl font-semibold tracking-[-.04em]">Recent activity</h2></div>
          {summaryQuery.isError && <QueryError retry={() => void summaryQuery.refetch()} />}
          <div className="relative ml-2 border-l border-border pl-6">
            {(summary?.recentActivity ?? []).length === 0 && !summaryQuery.isLoading && <p className="py-4 text-sm text-muted-foreground" data-testid="empty-activity">Activity will appear as creators show up.</p>}
            {(summary?.recentActivity ?? []).map((item, index) => (
              <div key={`${item.createdAt}-${index}`} className="relative mb-7 last:mb-0" data-testid={`activity-item-${index}`}>
                <span className="absolute -left-[30px] top-1 size-2 rounded-full border-2 border-background bg-primary" />
                <p className="text-sm font-medium">{item.label}</p><p className="mt-1 text-xs leading-5 text-muted-foreground">{item.detail}</p><p className="mt-2 font-mono text-[10px] uppercase text-muted-foreground">{dateLabel(item.createdAt)}</p>
              </div>
            ))}
            {summaryQuery.isLoading && <><SkeletonBlock className="mb-7 h-12" /><SkeletonBlock className="h-12" /></>}
          </div>
        </section>
      </div>
      <section className="mt-20 border-t border-border pt-10">
        <div className="grid gap-8 md:grid-cols-3">
          {[
            ['01', 'Projects set the brief.', 'Fund a pool, define the signal, and watch your budget move through the open.'],
            ['02', 'Creators bring the signal.', 'Post something worth stopping for. Quality, trust, and traction shape the score.'],
            ['03', 'The ledger tells the story.', 'A shared record of attention earned, XP awarded, and rewards estimated.'],
          ].map(([num, title, copy]) => <div key={num} className="group" data-testid={`principle-${num}`}><p className="font-mono text-xs text-primary">{num}</p><h3 className="mt-4 text-xl font-semibold tracking-[-.035em]">{title}</h3><p className="mt-3 text-sm leading-6 text-muted-foreground">{copy}</p></div>)}
        </div>
      </section>
    </div>
  );
}

function CampaignRow({ campaign, index = 0, onSelect }: { campaign: Campaign; index?: number; onSelect?: (id: number) => void }) {
  const content = (
    <>
      <div className="flex min-w-0 items-start gap-4"><span className="mt-1 font-mono text-xs text-muted-foreground">0{index + 1}</span><div className="min-w-0"><h3 className="truncate font-semibold tracking-[-.02em]">{campaign.name}</h3><p className="mt-1 line-clamp-1 text-sm text-muted-foreground">{campaign.brief || 'Open brief — create your own signal.'}</p></div></div>
      <div className="flex shrink-0 items-center gap-5 text-right"><div><p className="font-mono text-sm">{money(campaign.pool)}</p><p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">pool</p></div><div className="hidden sm:block"><p className="font-mono text-sm">{number(campaign.submissionsCount)}</p><p className="mt-1 text-[10px] uppercase tracking-wider text-muted-foreground">posts</p></div><ArrowUpRight size={16} className="text-muted-foreground transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" /></div>
    </>
  );
  return onSelect ? (
    <button type="button" onClick={() => onSelect(campaign.id)} className="group flex w-full items-center justify-between gap-5 rounded-sm border border-border bg-card p-5 text-left transition-transform hover:-translate-y-0.5 hover:border-foreground/30" data-testid={`button-campaign-${campaign.id}`}>{content}</button>
  ) : (
    <Link href={`/projects?campaign=${campaign.id}`} className="group flex items-center justify-between gap-5 rounded-sm border border-border bg-card p-5 transition-transform hover:-translate-y-0.5 hover:border-foreground/30" data-testid={`link-campaign-${campaign.id}`}>{content}</Link>
  );
}

function CampaignForm({ onCreated }: { onCreated?: (campaign: Campaign) => void }) {
  const client = useQueryClient();
  const mutation = useCreateCampaign();
  const [success, setSuccess] = useState(false);
  const form = useForm<CampaignFormValues>({ resolver: zodResolver(campaignSchema), defaultValues: { name: '', brief: '', pool: 5000, cycle: '2 weeks' } });
  const submit = (values: CampaignFormValues) => {
    setSuccess(false);
    const payload: CampaignInput = values;
    mutation.mutate({ data: payload }, {
      onSuccess: (campaign) => {
        void client.invalidateQueries({ queryKey: getListCampaignsQueryKey() });
        void client.invalidateQueries({ queryKey: getGetMarketplaceSummaryQueryKey() });
        setSuccess(true); form.reset({ name: '', brief: '', pool: 5000, cycle: '2 weeks' }); onCreated?.(campaign);
      },
    });
  };
  return (
    <div className="rounded-sm bg-foreground p-6 text-background sm:p-8">
      <div className="mb-7 flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">New allocation</p><h2 className="mt-2 text-2xl font-semibold tracking-[-.04em]">Launch a campaign</h2></div><Plus size={20} className="text-primary" /></div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(submit)} className="space-y-5" data-testid="form-create-campaign">
          <FormField control={form.control} name="name" render={({ field }) => <FormItem><FormLabel className="text-background/70">Campaign name</FormLabel><FormControl><Input {...field} placeholder="e.g. Protocol springboard" className="border-background/20 bg-background/10 text-background placeholder:text-background/40" data-testid="input-campaign-name" /></FormControl><FormMessage /></FormItem>} />
          <FormField control={form.control} name="brief" render={({ field }) => <FormItem><FormLabel className="text-background/70">The brief <span className="font-normal text-background/40">(optional)</span></FormLabel><FormControl><Textarea {...field} placeholder="What should creators make people notice?" className="min-h-20 resize-none border-background/20 bg-background/10 text-background placeholder:text-background/40" data-testid="input-campaign-brief" /></FormControl><FormMessage /></FormItem>} />
          <div className="grid gap-5 sm:grid-cols-2">
            <FormField control={form.control} name="pool" render={({ field }) => <FormItem><FormLabel className="text-background/70">Reward pool <span className="font-mono text-primary">USD</span></FormLabel><FormControl><Input {...field} type="number" min="1" className="border-background/20 bg-background/10 text-background" data-testid="input-campaign-pool" /></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="cycle" render={({ field }) => <FormItem><FormLabel className="text-background/70">Cycle</FormLabel><FormControl><select {...field} className="flex h-9 w-full rounded-md border border-background/20 bg-background/10 px-3 text-sm text-background outline-none focus:ring-1 focus:ring-primary" data-testid="select-campaign-cycle"><option className="text-foreground" value="1 week">1 week</option><option className="text-foreground" value="2 weeks">2 weeks</option><option className="text-foreground" value="4 weeks">4 weeks</option></select></FormControl><FormMessage /></FormItem>} />
          </div>
          {success && <p className="flex items-center gap-2 text-sm text-secondary" data-testid="status-campaign-success"><Check size={15} /> Campaign is live on the board.</p>}
          {mutation.isError && <p className="text-sm text-primary" data-testid="status-campaign-error">Could not launch this campaign. Try again.</p>}
          <Button type="submit" disabled={mutation.isPending} className="w-full bg-primary text-primary-foreground" data-testid="button-create-campaign">{mutation.isPending ? 'Launching…' : 'Launch campaign'} <ArrowUpRight size={15} /></Button>
        </form>
      </Form>
    </div>
  );
}

function RewardPoolPanel({ campaign }: { campaign: Campaign }) {
  const client = useQueryClient();
  const configQuery = useGetRewardPoolConfig();
  const fundingMutation = useRecordRewardPoolFunding();
  const swapMutation = useRecordRewardPoolSwap();
  const rootMutation = useRecordRewardPoolRoot();
  const distributionQuery = useGetRewardPoolDistribution(campaign.id, {
    query: {
      enabled: campaign.rewardStatus === 'swapped' || campaign.rewardStatus === 'root-published',
      queryKey: getGetRewardPoolDistributionQueryKey(campaign.id),
    },
  });
  const [ethAmount, setEthAmount] = useState('0.01');
  const [minGdOut, setMinGdOut] = useState('1');
  const [actionError, setActionError] = useState('');
  const [actionMessage, setActionMessage] = useState('');
  const configured = isRewardPoolConfigured() && Boolean(configQuery.data?.ready);
  const refresh = () => {
    void client.invalidateQueries({ queryKey: getGetCampaignQueryKey(campaign.id) });
    void client.invalidateQueries({ queryKey: getListCampaignsQueryKey() });
    void client.invalidateQueries({ queryKey: getGetRewardPoolDistributionQueryKey(campaign.id) });
  };

  const fund = async () => {
    setActionError('');
    setActionMessage('');
    try {
      const result = await createOnchainCampaign(ethAmount);
      await fundingMutation.mutateAsync({
        campaignId: campaign.id,
        data: {
          onchainCampaignId: result.onchainCampaignId,
          contractAddress: REWARD_POOL_CONTRACT_ADDRESS,
          projectWallet: result.address,
          ethFundedRaw: parseEther(ethAmount).toString(),
          txHash: result.hash,
        },
      });
      setActionMessage('Funding confirmed on Celo.');
      refresh();
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Funding did not complete.');
    }
  };

  const swap = async () => {
    if (campaign.onchainCampaignId === null || campaign.onchainCampaignId === undefined) return;
    setActionError('');
    setActionMessage('');
    try {
      const result = await finalizeOnchainSwap(campaign.onchainCampaignId, minGdOut);
      await swapMutation.mutateAsync({
        campaignId: campaign.id,
        data: { gdPoolRaw: result.gdPoolRaw, txHash: result.hash },
      });
      setActionMessage('Swap confirmed. The G$ pool is ready to split.');
      refresh();
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Swap did not complete.');
    }
  };

  const publish = async () => {
    if (campaign.onchainCampaignId === null || campaign.onchainCampaignId === undefined || !distributionQuery.data) return;
    setActionError('');
    setActionMessage('');
    try {
      const result = await publishOnchainRoot(campaign.onchainCampaignId, distributionQuery.data.merkleRoot as `0x${string}`);
      await rootMutation.mutateAsync({
        campaignId: campaign.id,
        data: { merkleRoot: distributionQuery.data.merkleRoot, txHash: result.hash },
      });
      setActionMessage('Merkle root published. Creators can now claim.');
      refresh();
    } catch (error) {
      setActionError(error instanceof Error ? error.message : 'Root publication did not complete.');
    }
  };

  return (
    <div className="mt-6 rounded-sm border border-secondary/50 bg-secondary/10 p-5" data-testid={`panel-reward-pool-${campaign.id}`}>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">G$ reward pool</p>
          <h4 className="mt-2 text-lg font-semibold tracking-[-.03em]">Onchain payout lifecycle</h4>
        </div>
        <span className="rounded-full bg-background px-3 py-1 font-mono text-[10px] uppercase tracking-wider">{campaign.rewardStatus}</span>
      </div>
      {!configured && (
        <p className="mt-4 rounded-sm border border-primary/30 bg-primary/5 p-3 text-xs leading-5 text-muted-foreground">
          Wallet actions are staged, but the deployed reward-pool contract address is not configured yet. Set <span className="font-mono text-foreground">VITE_REWARD_POOL_CONTRACT_ADDRESS</span> after deploying the reviewed contract.
        </p>
      )}
      {configured && campaign.rewardStatus === 'draft' && (
        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-end">
          <label className="flex-1 text-xs font-medium">ETH to fund
            <Input value={ethAmount} onChange={(event) => setEthAmount(event.target.value)} inputMode="decimal" className="mt-2" data-testid="input-reward-eth" />
          </label>
          <Button onClick={() => void fund()} disabled={fundingMutation.isPending} data-testid="button-fund-reward-pool">{fundingMutation.isPending ? 'Confirming…' : 'Fund on Celo'} <ArrowUpRight size={15} /></Button>
        </div>
      )}
      {configured && campaign.rewardStatus === 'funded' && (
        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-end">
          <label className="flex-1 text-xs font-medium">Minimum G$ out
            <Input value={minGdOut} onChange={(event) => setMinGdOut(event.target.value)} inputMode="numeric" className="mt-2" data-testid="input-min-gd-out" />
          </label>
          <Button onClick={() => void swap()} disabled={swapMutation.isPending} data-testid="button-finalize-reward-swap">{swapMutation.isPending ? 'Swapping…' : 'Finalize swap'} <ArrowUpRight size={15} /></Button>
        </div>
      )}
      {campaign.rewardStatus === 'swapped' && (
        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div><p className="font-mono text-lg">{campaign.gdPoolRaw} G$ units</p><p className="mt-1 text-xs text-muted-foreground">Distribution uses the actual swap output, not the USD estimate.</p></div>
          {configured && <Button onClick={() => void publish()} disabled={rootMutation.isPending || distributionQuery.isLoading || !distributionQuery.data} data-testid="button-publish-reward-root">{rootMutation.isPending ? 'Publishing…' : distributionQuery.isLoading ? 'Building split…' : 'Publish root'} <ArrowUpRight size={15} /></Button>}
        </div>
      )}
      {(campaign.rewardStatus === 'root-published' || campaign.rewardStatus === 'claiming') && <p className="mt-5 text-sm text-secondary"><Check size={15} className="mr-2 inline" /> Root published. Creators can claim their G$ share from the Creators page.</p>}
      {actionMessage && <p className="mt-4 text-sm text-secondary" data-testid="status-reward-pool-success">{actionMessage}</p>}
      {actionError && <p className="mt-4 text-sm text-destructive" data-testid="status-reward-pool-error">{actionError}</p>}
    </div>
  );
}

function Projects() {
  const query = useListCampaigns();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const detailQuery = useGetCampaign(selectedId ?? 0, { query: { enabled: !!selectedId, queryKey: getGetCampaignQueryKey(selectedId ?? 0) } });
  return (
    <div>
      <PageIntro eyebrow="Projects / Allocate" title={<>Give attention<br /><span className="text-primary">a direction.</span></>} description="Register a campaign, set a transparent reward pool, and let the marketplace make every creator contribution legible." action={<Button asChild variant="outline" data-testid="button-projects-top"><Link href="#launch">Launch a campaign <Plus size={15} /></Link></Button>} />
      <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_390px]">
        <section>
          <div className="mb-5 flex items-center justify-between border-b border-border pb-4"><div><p className="font-mono text-[11px] uppercase tracking-[.18em] text-muted-foreground">Active records</p><h2 className="mt-2 text-2xl font-semibold tracking-[-.04em]">Campaign board</h2></div><span className="rounded-full bg-secondary/60 px-3 py-1 font-mono text-[11px]" data-testid="text-campaign-count">{query.data?.length ?? 0} live</span></div>
          {query.isLoading && <div className="space-y-3"><SkeletonBlock className="h-28" /><SkeletonBlock className="h-28" /><SkeletonBlock className="h-28" /></div>}
          {query.isError && <QueryError retry={() => void query.refetch()} />}
          {!query.isLoading && !query.isError && (query.data ?? []).length === 0 && <div className="border border-dashed border-border p-12 text-center" data-testid="empty-projects"><Radar className="mx-auto text-primary" size={28} /><h3 className="mt-4 font-semibold">No campaigns in orbit.</h3><p className="mt-2 text-sm text-muted-foreground">Be the first project to put a pool behind a signal.</p></div>}
          <div className="space-y-3">{(query.data ?? []).map((campaign, index) => <CampaignRow key={campaign.id} campaign={campaign} index={index} onSelect={setSelectedId} />)}</div>
          {selectedId && (
            <div className="mt-7 rounded-sm border border-primary/40 bg-card p-6" data-testid={`panel-campaign-detail-${selectedId}`}>
              {detailQuery.isLoading && <SkeletonBlock className="h-24" />}
              {detailQuery.isError && <QueryError retry={() => void detailQuery.refetch()} />}
              {detailQuery.data && <><div className="flex items-start justify-between"><div><p className="font-mono text-[10px] uppercase tracking-wider text-primary">Campaign detail</p><h3 className="mt-2 text-xl font-semibold">{detailQuery.data.name}</h3></div><button type="button" onClick={() => setSelectedId(null)} className="text-muted-foreground hover:text-foreground" data-testid="button-close-campaign-detail"><X size={17} /></button></div><p className="mt-3 text-sm leading-6 text-muted-foreground">{detailQuery.data.brief || 'No brief supplied.'}</p><div className="mt-5 flex flex-wrap gap-5 border-t border-border pt-4 text-xs text-muted-foreground"><span><strong className="font-mono text-foreground">{money(detailQuery.data.pool)}</strong> pool</span><span><strong className="font-mono text-foreground">{number(detailQuery.data.xpAwarded)}</strong> XP awarded</span><span><strong className="font-mono text-foreground">{number(detailQuery.data.submissions.length)}</strong> submissions</span></div><RewardPoolPanel campaign={detailQuery.data} /></>}
            </div>
          )}
        </section>
        <section id="launch" className="lg:sticky lg:top-24 lg:self-start"><CampaignForm /></section>
      </div>
    </div>
  );
}

function Creators() {
  const campaigns = useListCampaigns();
  const client = useQueryClient();
  const mutation = useCreateSubmission();
  const claimMutation = useRecordRewardPoolClaim();
  const [result, setResult] = useState<Submission | null>(null);
  const [walletError, setWalletError] = useState('');
  const form = useForm<SubmissionFormValues>({ resolver: zodResolver(submissionSchema), defaultValues: { campaignId: campaigns.data?.[0]?.id ?? 0, handle: '', platform: 'X (Twitter)', link: '', accountAge: 'established', walletAddress: '' } });
  const firstCampaignId = campaigns.data?.[0]?.id ?? 0;
  useEffect(() => {
    if (firstCampaignId && form.getValues('campaignId') === 0) form.setValue('campaignId', firstCampaignId);
  }, [firstCampaignId, form]);
  const walletAddress = form.watch('walletAddress');
  const selectedCampaign = campaigns.data?.find((item) => item.id === Number(form.watch('campaignId')));
  const claimQuery = useGetRewardPoolClaim(selectedCampaign?.id ?? 0, walletAddress || '', {
    query: {
      enabled: Boolean(selectedCampaign && walletAddress && /^0x[a-fA-F0-9]{40}$/.test(walletAddress) && (selectedCampaign.rewardStatus === 'root-published' || selectedCampaign.rewardStatus === 'claiming')),
      queryKey: getGetRewardPoolClaimQueryKey(selectedCampaign?.id ?? 0, walletAddress || ''),
    },
  });
  const connectCreatorWallet = async () => {
    setWalletError('');
    try {
      const { address } = await connectWallet();
      form.setValue('walletAddress', address, { shouldValidate: true });
    } catch (error) {
      setWalletError(error instanceof Error ? error.message : 'Could not connect wallet.');
    }
  };
  const submit = (values: SubmissionFormValues) => {
    setResult(null);
    mutation.mutate({ campaignId: values.campaignId, data: { handle: values.handle, platform: values.platform, link: values.link, accountAge: values.accountAge, walletAddress: values.walletAddress } }, {
      onSuccess: (submission) => {
        setResult(submission);
        void client.invalidateQueries({ queryKey: getGetCampaignQueryKey(values.campaignId) });
        void client.invalidateQueries({ queryKey: getListCampaignsQueryKey() });
        void client.invalidateQueries({ queryKey: getGetMarketplaceSummaryQueryKey() });
        void client.invalidateQueries({ queryKey: getGetCampaignLeaderboardQueryKey(values.campaignId) });
      },
    });
  };
  const claim = async () => {
    if (selectedCampaign?.onchainCampaignId === null || selectedCampaign?.onchainCampaignId === undefined || !claimQuery.data) return;
    setWalletError('');
    try {
      const result = await claimOnchainReward(selectedCampaign.onchainCampaignId, claimQuery.data.amountRaw, claimQuery.data.proof);
      await claimMutation.mutateAsync({
        campaignId: selectedCampaign.id,
        data: { walletAddress: claimQuery.data.walletAddress, amountRaw: claimQuery.data.amountRaw, txHash: result.hash },
      });
      void client.invalidateQueries({ queryKey: getListCampaignsQueryKey() });
      void client.invalidateQueries({ queryKey: getGetRewardPoolClaimQueryKey(selectedCampaign.id, claimQuery.data.walletAddress) });
    } catch (error) {
      setWalletError(error instanceof Error ? error.message : 'Claim did not complete.');
    }
  };
  return (
    <div>
      <PageIntro eyebrow="Creators / Submit" title={<>Show your<br /><span className="text-primary">signal.</span></>} description="Submit a post to an active campaign. Our scoring reads engagement and account trust together — not vanity metrics alone." action={<div className="flex items-center gap-2 rounded-sm border border-secondary bg-secondary/20 px-4 py-3 text-xs font-medium"><Sparkles size={15} className="text-primary" /> Scoring is transparent</div>} />
      <div className="grid gap-10 lg:grid-cols-[1fr_390px]">
        <section className="rounded-sm border border-border bg-card p-6 sm:p-9">
          <div className="mb-8 flex items-center gap-3"><span className="grid size-9 place-items-center rounded-sm bg-primary text-primary-foreground"><Send size={16} /></span><div><p className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Creator intake</p><h2 className="text-xl font-semibold tracking-[-.035em]">Score a post</h2></div></div>
          {campaigns.isLoading && <SkeletonBlock className="h-10" />}
          {campaigns.isError && <QueryError retry={() => void campaigns.refetch()} />}
          {!campaigns.isLoading && !campaigns.isError && (campaigns.data ?? []).length === 0 && <div className="rounded-sm border border-dashed border-border p-8 text-center text-sm text-muted-foreground" data-testid="empty-creator-campaigns">There are no campaigns open for submissions right now.</div>}
          {(campaigns.data ?? []).length > 0 && <Form {...form}><form onSubmit={form.handleSubmit(submit)} className="space-y-6" data-testid="form-create-submission">
            <FormField control={form.control} name="campaignId" render={({ field }) => <FormItem><FormLabel>Campaign</FormLabel><FormControl><select {...field} value={field.value} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-1 focus:ring-ring" data-testid="select-submission-campaign">{(campaigns.data ?? []).map((campaign) => <option key={campaign.id} value={campaign.id}>{campaign.name} · {money(campaign.pool)} pool</option>)}</select></FormControl><FormMessage /></FormItem>} />
            <div className="grid gap-6 sm:grid-cols-2"><FormField control={form.control} name="handle" render={({ field }) => <FormItem><FormLabel>Creator handle</FormLabel><FormControl><Input {...field} placeholder="@yourhandle" data-testid="input-submission-handle" /></FormControl><FormMessage /></FormItem>} /><FormField control={form.control} name="platform" render={({ field }) => <FormItem><FormLabel>Platform</FormLabel><FormControl><select {...field} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-1 focus:ring-ring" data-testid="select-submission-platform">{Object.values(SubmissionInputPlatform).map((value) => <option key={value} value={value}>{value}</option>)}</select></FormControl><FormMessage /></FormItem>} /></div>
            <FormField control={form.control} name="link" render={({ field }) => <FormItem><FormLabel>Post URL</FormLabel><FormControl><div className="relative"><ExternalLink size={15} className="absolute left-3 top-3 text-muted-foreground" /><Input {...field} className="pl-9" placeholder="https://..." data-testid="input-submission-link" /></div></FormControl><FormMessage /></FormItem>} />
            <FormField control={form.control} name="accountAge" render={({ field }) => <FormItem><FormLabel>Account age</FormLabel><FormControl><select {...field} className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm outline-none focus:ring-1 focus:ring-ring" data-testid="select-submission-account-age">{Object.values(SubmissionInputAccountAge).map((value) => <option key={value} value={value}>{value === 'under-30-days' ? 'Under 30 days' : value === '1-6-months' ? '1–6 months' : 'Established'}</option>)}</select></FormControl><FormMessage /></FormItem>} />
             <FormField control={form.control} name="walletAddress" render={({ field }) => <FormItem><div className="flex items-center justify-between"><FormLabel>Claim wallet</FormLabel><button type="button" onClick={() => void connectCreatorWallet()} className="font-mono text-[10px] uppercase tracking-wider text-primary hover:underline">Connect wallet</button></div><FormControl><Input {...field} placeholder="0x..." className="font-mono text-xs" data-testid="input-submission-wallet" /></FormControl><p className="text-xs text-muted-foreground">This address receives the G$ allocation after the campaign root is published.</p><FormMessage /></FormItem>} />
             {walletError && <p className="text-sm text-destructive" data-testid="status-wallet-error">{walletError}</p>}
            <div className="flex items-start gap-3 border-t border-border pt-5 text-xs leading-5 text-muted-foreground"><Check size={15} className="mt-0.5 shrink-0 text-secondary" /> Your post is scored against the selected campaign’s brief and recorded with its engagement snapshot.</div>
            {mutation.isError && <p className="text-sm text-destructive" data-testid="status-submission-error">We couldn't score that post. Check the link and try again.</p>}
            <Button type="submit" disabled={mutation.isPending} className="w-full sm:w-auto" data-testid="button-submit-post">{mutation.isPending ? 'Scoring…' : 'Submit for scoring'} <ArrowRight size={15} /></Button>
          </form></Form>}
        </section>
        <aside className="space-y-5">
          <div className="rounded-sm bg-secondary/55 p-6" data-testid="panel-scoring-explanation"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">How it reads</p><h2 className="mt-3 text-2xl font-semibold tracking-[-.045em]">Reach is only<br />part of the signal.</h2><div className="mt-7 space-y-4">{[['Engagement', 'Likes, reposts, and replies'], ['Trust', 'Account age and credibility'], ['Consistency', 'A clear, campaign-fit post']].map(([label, copy]) => <div key={label} className="border-t border-foreground/15 pt-3"><div className="flex items-center justify-between text-sm font-medium"><span>{label}</span><span className="font-mono text-xs text-primary">01</span></div><p className="mt-1 text-xs text-muted-foreground">{copy}</p></div>)}</div></div>
          {result && <div className="enter-up rounded-sm border border-primary/40 bg-card p-6" data-testid="panel-submission-result"><p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.18em] text-primary"><Check size={14} /> Recorded in the open</p><p className="mt-4 text-4xl font-semibold tracking-[-.06em]">{number(result.xp)} <span className="text-base font-normal text-muted-foreground">XP</span></p><p className="mt-2 text-sm leading-6 text-muted-foreground">Nice signal, {result.handle}. Your post earned {number(result.xp)} XP with a {Math.round(result.trust * 100)}% trust score.</p><Link href={`/leaderboard?campaign=${result.campaignId}`} className="mt-5 inline-flex items-center gap-2 text-sm font-medium text-primary" data-testid="link-view-submission-leaderboard">View campaign leaderboard <ArrowRight size={14} /></Link></div>}
           {selectedCampaign && (selectedCampaign.rewardStatus === 'root-published' || selectedCampaign.rewardStatus === 'claiming') && walletAddress && (
             <div className="rounded-sm border border-secondary/50 bg-secondary/10 p-6" data-testid="panel-creator-claim">
               <p className="font-mono text-[10px] uppercase tracking-[.18em] text-primary">G$ claim</p>
               <h3 className="mt-3 text-lg font-semibold">Your earned allocation</h3>
               {claimQuery.isLoading && <p className="mt-3 text-sm text-muted-foreground">Looking up your Merkle proof…</p>}
               {claimQuery.isError && <p className="mt-3 text-sm text-muted-foreground">No claimable allocation was found for this wallet in the selected campaign.</p>}
               {claimQuery.data && <><p className="mt-4 font-mono text-2xl">{claimQuery.data.amountRaw} <span className="text-sm text-muted-foreground">G$ units</span></p><p className="mt-2 text-xs leading-5 text-muted-foreground">The amount is verified against the published root. G$ token decimals are intentionally not assumed here.</p><Button className="mt-5 w-full" onClick={() => void claim()} disabled={claimMutation.isPending || !isRewardPoolConfigured()} data-testid="button-claim-gdollar">{claimMutation.isPending ? 'Claiming…' : 'Claim G$'} <ArrowUpRight size={15} /></Button>{!isRewardPoolConfigured() && <p className="mt-3 text-xs text-muted-foreground">Configure the deployed reward-pool contract before signing.</p>}</>}
             </div>
           )}
          {selectedCampaign && !result && <div className="rounded-sm border border-border p-6"><p className="font-mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">Selected brief</p><h3 className="mt-3 font-semibold">{selectedCampaign.name}</h3><p className="mt-2 text-sm leading-6 text-muted-foreground">{selectedCampaign.brief || 'Make something people want to pass on.'}</p></div>}
        </aside>
      </div>
    </div>
  );
}

function Leaderboard() {
  const campaigns = useListCampaigns();
  const params = useParams<{ campaignId?: string }>();
  const [selectedId, setSelectedId] = useState<number | null>(params.campaignId ? Number(params.campaignId) : null);
  const campaignId = selectedId ?? campaigns.data?.[0]?.id ?? 0;
  const query = useGetCampaignLeaderboard(campaignId, { query: { enabled: campaignId > 0, queryKey: getGetCampaignLeaderboardQueryKey(campaignId) } });
  const rows = useMemo(() => query.data ?? [], [query.data]);
  return (
    <div>
      <PageIntro eyebrow="Leaderboard / Distribute" title={<>Reward the<br /><span className="text-primary">real ones.</span></>} description="Inspect the ranked record for any campaign. XP, trust, and estimated rewards stay connected so the split makes sense." />
      <div className="mb-8 flex flex-col gap-4 border-y border-border py-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3"><Trophy size={17} className="text-primary" /><span className="text-sm font-medium">Viewing campaign</span></div>
        <div className="relative w-full sm:w-80"><select value={selectedId ?? ''} onChange={(event) => setSelectedId(Number(event.target.value))} className="h-10 w-full appearance-none rounded-sm border border-input bg-card px-3 pr-9 text-sm outline-none focus:ring-1 focus:ring-ring" data-testid="select-leaderboard-campaign"><option value="" disabled>Select a campaign</option>{(campaigns.data ?? []).map((campaign) => <option key={campaign.id} value={campaign.id}>{campaign.name}</option>)}</select><ChevronDown size={15} className="pointer-events-none absolute right-3 top-3 text-muted-foreground" /></div>
      </div>
      {campaigns.isLoading || query.isLoading ? <div className="space-y-2"><SkeletonBlock className="h-16" /><SkeletonBlock className="h-16" /><SkeletonBlock className="h-16" /></div> : query.isError ? <QueryError retry={() => void query.refetch()} /> : rows.length === 0 ? <div className="border border-dashed border-border p-14 text-center" data-testid="empty-leaderboard"><Trophy size={28} className="mx-auto text-primary" /><h3 className="mt-4 font-semibold">No ranked creators yet.</h3><p className="mt-2 text-sm text-muted-foreground">The first post sets the leaderboard in motion.</p></div> : (
        <div className="overflow-x-auto rounded-sm border border-border bg-card" data-testid="table-leaderboard"><div className="min-w-[760px]"><div className="grid grid-cols-[70px_1.7fr_100px_100px_110px_120px_100px] gap-4 border-b border-border bg-muted/40 px-5 py-3 font-mono text-[10px] uppercase tracking-[.12em] text-muted-foreground"><span>Rank</span><span>Creator</span><span>Posts</span><span>XP</span><span>Share</span><span>Est. reward</span><span>Trust</span></div>{rows.map((row, index) => <LeaderboardRowView key={`${row.handle}-${index}`} row={row} />)}</div></div>
      )}
      <div className="mt-8 grid gap-4 sm:grid-cols-3"><div className="rounded-sm border border-border bg-card p-5"><BarChart3 size={16} className="text-primary" /><p className="mt-5 text-sm font-medium">Share follows contribution</p><p className="mt-2 text-xs leading-5 text-muted-foreground">XP turns activity into a legible slice of the pool.</p></div><div className="rounded-sm border border-border bg-card p-5"><Activity size={16} className="text-primary" /><p className="mt-5 text-sm font-medium">The record stays live</p><p className="mt-2 text-xs leading-5 text-muted-foreground">New scored posts update the campaign view, not a hidden spreadsheet.</p></div><div className="rounded-sm border border-border bg-card p-5"><FileText size={16} className="text-primary" /><p className="mt-5 text-sm font-medium">Built for receipts</p><p className="mt-2 text-xs leading-5 text-muted-foreground">Every row points back to the creator signal that earned it.</p></div></div>
    </div>
  );
}

function LeaderboardRowView({ row }: { row: LeaderboardRow }) {
  return <div className={`grid grid-cols-[70px_1.7fr_100px_100px_110px_120px_100px] items-center gap-4 border-b border-border px-5 py-5 last:border-0 ${row.rank === 1 ? 'bg-accent/15' : ''}`} data-testid={`row-leaderboard-${row.rank}`}><span className={`font-mono text-lg ${row.rank <= 3 ? 'text-primary' : 'text-muted-foreground'}`}>{String(row.rank).padStart(2, '0')}</span><div className="flex items-center gap-3"><span className="grid size-9 place-items-center rounded-full bg-foreground text-xs font-bold text-background">{row.handle.replace('@', '').slice(0, 2).toUpperCase()}</span><div><p className="text-sm font-semibold">{row.handle}</p><p className="mt-0.5 text-xs text-muted-foreground">{row.platform}</p></div></div><span className="font-mono text-sm">{number(row.posts)}</span><span className="font-mono text-sm">{number(row.xp)}</span><span className="font-mono text-sm">{(row.share * 100).toFixed(1)}%</span><span className="font-mono text-sm font-medium text-primary">{money(row.estimatedReward)}</span><span className="font-mono text-sm">{Math.round(row.trust * 100)}%</span></div>;
}

function Router() {
  return <RoutedErrorBoundary><Shell><Switch><Route path="/" component={Overview} /><Route path="/projects" component={Projects} /><Route path="/creators" component={Creators} /><Route path="/leaderboard" component={Leaderboard} /><Route component={NotFound} /></Switch></Shell></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;