import {
  createPublicClient,
  createWalletClient,
  custom,
  decodeEventLog,
  http,
  parseEther,
  type Address,
  type Hex,
} from 'viem';
import { celo } from 'viem/chains';

export const REWARD_POOL_CHAIN_ID = 42220;
export const GDOLLAR_TOKEN_ADDRESS = '0x62B8B11039FcfE5aB0C56E502b1C372A3d2a9c7A' as Address;
export const REWARD_POOL_CONTRACT_ADDRESS = (import.meta.env.VITE_REWARD_POOL_CONTRACT_ADDRESS || '') as Address | '';
export const CLAIM_WINDOW_SECONDS = 60n * 60n * 24n * 14n;

export const rewardPoolAbi = [
  {
    type: 'function',
    name: 'createCampaign',
    stateMutability: 'payable',
    inputs: [
      { name: 'requireIdentity', type: 'bool' },
      { name: 'claimWindowSeconds', type: 'uint64' },
    ],
    outputs: [{ name: 'campaignId', type: 'uint256' }],
  },
  {
    type: 'function',
    name: 'finalizeSwap',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'campaignId', type: 'uint256' },
      { name: 'minGdOut', type: 'uint256' },
    ],
    outputs: [],
  },
  {
    type: 'function',
    name: 'publishRoot',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'campaignId', type: 'uint256' },
      { name: 'merkleRoot', type: 'bytes32' },
    ],
    outputs: [],
  },
  {
    type: 'function',
    name: 'claim',
    stateMutability: 'nonpayable',
    inputs: [
      { name: 'campaignId', type: 'uint256' },
      { name: 'amount', type: 'uint256' },
      { name: 'proof', type: 'bytes32[]' },
    ],
    outputs: [],
  },
  {
    type: 'function',
    name: 'campaigns',
    stateMutability: 'view',
    inputs: [{ name: '', type: 'uint256' }],
    outputs: [
      { name: 'project', type: 'address' },
      { name: 'ethDeposited', type: 'uint256' },
      { name: 'gdPool', type: 'uint256' },
      { name: 'gdClaimed', type: 'uint256' },
      { name: 'merkleRoot', type: 'bytes32' },
      { name: 'requireIdentity', type: 'bool' },
      { name: 'swapped', type: 'bool' },
      { name: 'finalized', type: 'bool' },
      { name: 'claimDeadline', type: 'uint64' },
    ],
  },
  {
    type: 'event',
    name: 'CampaignCreated',
    inputs: [
      { indexed: true, name: 'campaignId', type: 'uint256' },
      { indexed: true, name: 'project', type: 'address' },
      { indexed: false, name: 'ethDeposited', type: 'uint256' },
      { indexed: false, name: 'requireIdentity', type: 'bool' },
    ],
  },
] as const;

declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
    };
  }
}

export const isRewardPoolConfigured = () => Boolean(REWARD_POOL_CONTRACT_ADDRESS);

function getConfiguredContractAddress(): Address {
  if (!REWARD_POOL_CONTRACT_ADDRESS) {
    throw new Error('The reward-pool contract address is not configured.');
  }
  return REWARD_POOL_CONTRACT_ADDRESS;
}

export const publicClient = createPublicClient({
  chain: celo,
  transport: http(),
});

export function getWalletClient() {
  if (!window.ethereum) {
    throw new Error('Install a browser wallet to use the G$ reward pool.');
  }
  return createWalletClient({
    chain: celo,
    transport: custom(window.ethereum),
  });
}

export async function connectWallet() {
  const walletClient = getWalletClient();
  const [address] = await walletClient.requestAddresses();
  const chainId = await walletClient.getChainId();
  if (chainId !== REWARD_POOL_CHAIN_ID) {
    try {
      await walletClient.switchChain({ id: REWARD_POOL_CHAIN_ID });
    } catch {
      throw new Error('Switch your wallet to Celo before continuing.');
    }
  }
  return { walletClient, address };
}

export async function createOnchainCampaign(ethAmount: string) {
  const contractAddress = getConfiguredContractAddress();
  const { walletClient, address } = await connectWallet();
  const hash = await walletClient.writeContract({
    address: contractAddress,
    abi: rewardPoolAbi,
    functionName: 'createCampaign',
    args: [false, CLAIM_WINDOW_SECONDS],
    account: address,
    value: parseEther(ethAmount),
  });
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  const createdLog = receipt.logs.find((log) => {
    try {
      return decodeEventLog({ abi: rewardPoolAbi, data: log.data, topics: log.topics }).eventName === 'CampaignCreated';
    } catch {
      return false;
    }
  });
  if (!createdLog) throw new Error('The funding transaction completed without a campaign id.');
  const decoded = decodeEventLog({ abi: rewardPoolAbi, data: createdLog.data, topics: createdLog.topics });
  return { hash, address, onchainCampaignId: Number(decoded.args.campaignId) };
}

export async function finalizeOnchainSwap(onchainCampaignId: number, minGdOut: string) {
  const contractAddress = getConfiguredContractAddress();
  const { walletClient, address } = await connectWallet();
  const hash = await walletClient.writeContract({
    address: contractAddress,
    abi: rewardPoolAbi,
    functionName: 'finalizeSwap',
    args: [BigInt(onchainCampaignId), BigInt(minGdOut)],
    account: address,
  });
  await publicClient.waitForTransactionReceipt({ hash });
  const onchainCampaign = await publicClient.readContract({
    address: contractAddress,
    abi: rewardPoolAbi,
    functionName: 'campaigns',
    args: [BigInt(onchainCampaignId)],
  });
  return { hash, gdPoolRaw: onchainCampaign[2].toString() };
}

export async function publishOnchainRoot(onchainCampaignId: number, merkleRoot: Hex) {
  const contractAddress = getConfiguredContractAddress();
  const { walletClient, address } = await connectWallet();
  const hash = await walletClient.writeContract({
    address: contractAddress,
    abi: rewardPoolAbi,
    functionName: 'publishRoot',
    args: [BigInt(onchainCampaignId), merkleRoot],
    account: address,
  });
  await publicClient.waitForTransactionReceipt({ hash });
  return { hash };
}

export async function claimOnchainReward(onchainCampaignId: number, amountRaw: string, proof: string[]) {
  const contractAddress = getConfiguredContractAddress();
  const { walletClient, address } = await connectWallet();
  const hash = await walletClient.writeContract({
    address: contractAddress,
    abi: rewardPoolAbi,
    functionName: 'claim',
    args: [BigInt(onchainCampaignId), BigInt(amountRaw), proof as Hex[]],
    account: address,
  });
  await publicClient.waitForTransactionReceipt({ hash });
  return { hash, address };
}